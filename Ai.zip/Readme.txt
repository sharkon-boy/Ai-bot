## Guide of this bot
1. npm install 'javascript-obfuscator'
2. create a folder w mkdir src and dist
3. put or copy file package.json to folder src
4. modif your obfuscate.js w name folder exp : 'data'
5. run file obfuscate.js
6. test run cd dist && node index.js
7. extrak all file from folder dist to zip
8. upload zip folder dist to panel
