const cmdIcons = {
    dotIcon: 'https://cdn.discordapp.com/emojis/915658913850998794.gif',
    sharIcon:'https://cdn.discordapp.com/emojis/1239708991274225765.gif',
    akatIcon: 'https://cdn.discordapp.com/emojis/1433692591559413770.gif',
    ZIcon: 'https://cdn.discordapp.com/emojis/1390013972081807481.gif',
    SIcon: 'https://cdn.discordapp.com/emojis/1433831296316080198.gif',
    BIcon: 'https://cdn.discordapp.com/emojis/1434782661909545000.gif',
    serverinfoIcon: 'https://cdn.discordapp.com/emojis/942629018296025128.gif',
    YouTubeIcon: 'https://cdn.discordapp.com/emojis/1229455855192379514.png',
    FaceBookIcon: 'https://cdn.discordapp.com/emojis/788969884062711818.png',
    TwitchIcon: 'https://cdn.discordapp.com/emojis/1229455826356404275.gif',
    InstagramIcon: 'https://cdn.discordapp.com/emojis/1188371472104837191.png',
    msgIcon: 'https://cdn.discordapp.com/emojis/915167284648116244.png',
    rippleIcon: 'https://cdn.discordapp.com/emojis/903301195307843595.gif',
    levelUpIcon: 'https://cdn.discordapp.com/emojis/908223980438163476.gif',
    disIcon: 'https://cdn.discordapp.com/emojis/1434044901921914881.gif',
    SSRRIcon: 'https://cdn.discordapp.com/emojis/1334648756649590805.png',
    
    // ICON BARU YANG DITAMBAHKAN - PERBAIKI NAMA YANG SALAH
    itachiIcon: 'https://cdn.discordapp.com/emojis/1433781281795080333.gif',
    vblueIcon: 'https://cdn.discordapp.com/emojis/1433781629037449258.gif',
    goku1Icon: 'https://cdn.discordapp.com/emojis/1434800061572710410.gif',
    goku2Icon: 'https://cdn.discordapp.com/emojis/1434799940705583175.gif',
    alarmIcon: 'https://cdn.discordapp.com/emojis/1440153105370058924.gif',
    shankIcon: 'https://cdn.discordapp.com/emojis/1433831296316080198.gif',
    bgokuIcon: 'https://cdn.discordapp.com/emojis/1434782661909545000.gif',
    plerIcon: 'https://cdn.discordapp.com/emojis/1437797662194798592.gif',
    
    // ICON BARU LAGI - PERBAIKI TYPO
    catIcon: 'https://cdn.discordapp.com/emojis/1390014326391443556.gif',
    ichigoIcon: 'https://cdn.discordapp.com/emojis/1235234177658388521.gif',
    boydIcon: 'https://cdn.discordapp.com/emojis/1239807604054691841.gif' // Fixed dari 'boydIcon' ke 'boydIcon'
};

module.exports = cmdIcons;
