const JavaScriptObfuscator = require('javascript-obfuscator');
const fs = require('fs');
const path = require('path');

console.log('🚀 Starting HYBRID Obfuscation (Files + Folders)...');

// === 🔥 KUSTOMISASI DI SINI ===
const foldersToObfuscate = [
    './modules',          // ✅ Semua file JS dalam folder modules
];

const filesToObfuscate = [
    './index.js',         // ✅ File utama
];

// === JANGAN EDIT DI BAWAH INI ===
const config = {
    outputDir: './dist',
    backupDir: './backup'
};

const obfuscationOptions = {
    compact: true,
    controlFlowFlattening: true,
    controlFlowFlatteningThreshold: 0.75,
    deadCodeInjection: true,
    deadCodeInjectionThreshold: 0.3,
    debugProtection: false,
    identifierNamesGenerator: 'hexadecimal',
    stringArray: true,
    stringArrayEncoding: ['rc4'],
    stringArrayThreshold: 0.75,
    transformObjectKeys: true,
    selfDefending: true
};

// === FUNGSI MENDAPATKAN SEMUA FILE JS DALAM FOLDER ===
function getAllJSFilesFromFolders(folders) {
    let allFiles = [];
    
    folders.forEach(folder => {
        if (!fs.existsSync(folder)) {
            console.log(`❌ Folder not found: ${folder}`);
            return;
        }
        
        function scanDirectory(dir) {
            const items = fs.readdirSync(dir);
            
            items.forEach(item => {
                const fullPath = path.join(dir, item);
                const stat = fs.statSync(fullPath);
                
                if (stat.isDirectory()) {
                    scanDirectory(fullPath);
                } else if (item.endsWith('.js')) {
                    allFiles.push(fullPath);
                }
            });
        }
        
        scanDirectory(folder);
    });
    
    return allFiles;
}

// === FUNGSI OBFUSCATE FILE ===
function obfuscateFiles(files) {
    console.log('\n📋 FILES TO OBFUSCATE:');
    
    // 🔥 FILTER: Hanya file .js yang diobfuscate
    const jsFiles = files.filter(file => file.endsWith('.js'));
    
    jsFiles.forEach((file, index) => {
        console.log(`   ${index + 1}. 🎯 ${file}`);
    });

    let successCount = 0;
    let failCount = 0;

    jsFiles.forEach(sourcePath => {
        console.log(`\n🔨 Processing: ${sourcePath}`);
        
        if (!fs.existsSync(sourcePath)) {
            console.log(`   ❌ File not found: ${sourcePath}`);
            failCount++;
            return;
        }

        try {
            const originalCode = fs.readFileSync(sourcePath, 'utf-8');
            
            if (originalCode.trim().length < 10) {
                console.log(`   ⚡ Skipped (empty file): ${sourcePath}`);
                return;
            }

            const obfuscatedResult = JavaScriptObfuscator.obfuscate(originalCode, obfuscationOptions);
            const obfuscatedCode = obfuscatedResult.getObfuscatedCode();
            
            const targetPath = path.join(config.outputDir, sourcePath);
            const targetDir = path.dirname(targetPath);
            
            if (!fs.existsSync(targetDir)) {
                fs.mkdirSync(targetDir, { recursive: true });
            }
            
            const finalCode = `/**
 * 🔒 OBFUSCATED - ${path.basename(sourcePath)}
 * Obfuscated: ${new Date().toLocaleString('id-ID')}
 */

${obfuscatedCode}`;

            fs.writeFileSync(targetPath, finalCode);
            console.log(`   ✅ Obfuscated: ${sourcePath}`);
            successCount++;
            
        } catch (error) {
            console.log(`   ❌ Failed: ${sourcePath} - ${error.message}`);
            failCount++;
        }
    });

    return { successCount, failCount };
}

// === FUNGSI COPY FILE LAINNYA ===
function copyOtherFiles() {
    console.log('\n📁 COPYING OTHER FILES...');
    let copiedCount = 0;

    const items = fs.readdirSync('.');
    items.forEach(item => {
        // Skip folder sistem dan folder dist
        if (item === 'node_modules' || item === 'backup' || item === 'dist' || item.startsWith('.')) {
            return;
        }

        const source = `./${item}`;
        const target = `./dist/${item}`;
        
        try {
            if (fs.statSync(source).isDirectory()) {
                // Skip folder yang sudah diobfuscate seluruhnya
                if (foldersToObfuscate.includes(source)) {
                    return;
                }
                
                // Copy folder recursive
                function copyRecursive(src, dest) {
                    if (fs.statSync(src).isDirectory()) {
                        if (!fs.existsSync(dest)) {
                            fs.mkdirSync(dest, { recursive: true });
                        }
                        fs.readdirSync(src).forEach(subItem => {
                            copyRecursive(path.join(src, subItem), path.join(dest, subItem));
                        });
                    } else {
                        fs.copyFileSync(src, dest);
                    }
                }
                copyRecursive(source, target);
                console.log(`   📂 Copied: ${item}/`);
            } else {
                // 🔥 COPY semua file non-JS (JSON, TXT, ENV, dll)
                if (!source.endsWith('.js')) {
                    fs.copyFileSync(source, target);
                    console.log(`   📄 Copied: ${item}`);
                }
            }
            copiedCount++;
        } catch (error) {
            console.log(`   ❌ Failed to copy ${item}: ${error.message}`);
        }
    });

    return copiedCount;
}

// === MAIN PROCESS ===
function main() {
    console.log('='.repeat(60));
    
    // 1. Dapatkan semua file JS dari folder
    const filesFromFolders = getAllJSFilesFromFolders(foldersToObfuscate);
    
    // 2. Gabungkan dengan file individual
    const allFilesToObfuscate = [...filesToObfuscate, ...filesFromFolders];
    
    console.log(`\n📁 Folders to scan: ${foldersToObfuscate.join(', ')}`);
    console.log(`📄 Individual files: ${filesToObfuscate.length} files`);
    console.log(`📄 Found in folders: ${filesFromFolders.length} JS files`);
    
    if (allFilesToObfuscate.length === 0) {
        console.log('❌ No files found to obfuscate');
        return;
    }
    
    // Buat folder output
    if (!fs.existsSync(config.outputDir)) {
        fs.mkdirSync(config.outputDir, { recursive: true });
    }
    
    // Obfuscate files (hanya .js)
    const result = obfuscateFiles(allFilesToObfuscate);
    
    // Copy semua file lainnya (non-JS)
    const copiedCount = copyOtherFiles();
    
    console.log('\n' + '='.repeat(60));
    console.log('🎉 HYBRID OBFUSCATION COMPLETED!');
    console.log('='.repeat(60));
    console.log('📊 RESULTS:');
    console.log(`   ✅ Obfuscated: ${result.successCount} JS files`);
    console.log(`   ❌ Failed: ${result.failCount} files`);
    console.log(`   📋 Copied: ${copiedCount} other files/folders`);
    console.log('\n🚀 HOW TO RUN:');
    console.log('   cd dist');
    console.log('   node index.js');
    console.log('='.repeat(60));
}

// Run
main();
