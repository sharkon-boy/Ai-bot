const { Client, GatewayIntentBits, ActivityType } = require('discord.js');
const axios = require('axios');

// Config with API
const config = {
    discord: {
        token: "MTM3NzQ3OTUyMDAyNTcxMDY0NQ.GONlu2.fRbRlS8kgOeaYLUPhpo8gw8xHFwIHQdjzXLVMw",
        clientId: "1377479520025710645"
    },
    groq: {
        apiKey: "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"
    },
    channels: {
        allowed_channel_ids: ["1238693417975025704"]
    }
};

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

// Available models on Groq
const AVAILABLE_MODELS = [
    "llama-3.1-8b-instant",
    "llama-3.1-70b-versatile",
    "mixtral-8x7b-32768",
    "gemma2-9b-it"
];

// Chat function with Groq API
async function chatWithAI(prompt) {
    try {
        const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
            model: "llama-3.1-8b-instant",
            messages: [{ role: "user", content: prompt }],
            temperature: 0.7,
            max_tokens: 1024,
            stream: false
        }, {
            headers: {
                'Authorization': `Bearer ${config.groq.apiKey}`,
                'Content-Type': 'application/json'
            },
            timeout: 30000
        });
        
        return response.data.choices[0].message.content;
    } catch (error) {
        // Only log error type, not the full response
        if (error.response?.data?.error?.message) {
            console.error('AI API Error:', error.response.data.error.message);
        } else {
            console.error('AI API Error:', error.message);
        }
        
        // Try alternative model if error
        if (error.response?.data?.error?.code === 'model_decommissioned') {
            return await tryAlternativeModel(prompt);
        }
        
        // Fallback responses in English
        const fallbackResponses = [
            "Sorry, I'm busy right now. Try again later!",
            "AI server is currently full, please wait a moment!",
            "Oops, an error occurred. Try asking again!",
            "I can't respond at the moment, please try again later!"
        ];
        
        return fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
    }
}

// Function to try alternative models
async function tryAlternativeModel(prompt) {
    const alternativeModels = [
        "llama-3.1-70b-versatile",
        "mixtral-8x7b-32768", 
        "gemma2-9b-it"
    ];
    
    for (const model of alternativeModels) {
        try {
            const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
                model: model,
                messages: [{ role: "user", content: prompt }],
                temperature: 0.7,
                max_tokens: 512
            }, {
                headers: {
                    'Authorization': `Bearer ${config.groq.apiKey}`,
                    'Content-Type': 'application/json'
                },
                timeout: 15000
            });
            
            return response.data.choices[0].message.content;
        } catch (error) {
            continue;
        }
    }
    
    return "Sorry, all models are currently unavailable. Please try again later!";
}

client.on('ready', () => {
    console.log(`✅ Bot successfully logged in as ${client.user.tag}`);
    console.log(`🤖 Using Groq AI`);
    console.log(`🚀 Model: llama-3.1-8b-instant`);
    
    client.user.setPresence({
        activities: [{ 
            name: 'AI | !help', 
            type: ActivityType.Playing 
        }],
        status: 'online'
    });
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    
    // Check if channel is allowed
    if (!config.channels.allowed_channel_ids.includes(message.channel.id)) {
        return;
    }

    // Help command
    if (message.content.startsWith('!help')) {
        const helpMessage = `
🤖 **AI Bot Commands:**
• **!help** - Show this help message
• **!info** - Bot information
• **!model** - Check current model
• **Type any message** - Chat with AI

📊 **Using:** Groq API
⚡ **Model:** Llama 3.1 8B Instant
🎯 **Status:** Fast and Boom
        `;
        return message.reply(helpMessage);
    }

    // Info command
    if (message.content.startsWith('!info')) {
        return message.reply('🤖 This bot uses Groq API with Llama 3.1 which is super fast!');
    }

    // Model info command
    if (message.content.startsWith('!model')) {
        return message.reply('🚀 **Current Model:** Llama 3.1 8B Instant\n⚡ **Speed:** Very Fast\n');
    }

    // Ignore short messages or commands
    if (message.content.length < 2 || message.content.startsWith('!')) return;

    try {
        // Typing indicator
        message.channel.sendTyping();
        
        // Process with AI (NO console.log for user messages or AI responses)
        const aiResponse = await chatWithAI(message.content);
        
        // Split long messages
        if (aiResponse && aiResponse.length > 2000) {
            const chunks = aiResponse.match(/[\s\S]{1,1990}/g);
            for (let i = 0; i < Math.min(chunks.length, 3); i++) {
                if (i === 0) {
                    await message.reply(chunks[i] + `\n\n[Part ${i+1}/${chunks.length}]`);
                } else {
                    await message.channel.send(chunks[i] + `\n\n[Part ${i+1}/${chunks.length}]`);
                }
                // Delay between chunks
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        } else if (aiResponse) {
            await message.reply(aiResponse);
        } else {
            await message.reply('❌ Sorry, cannot respond at the moment. Please try again later!');
        }

    } catch (error) {
        console.error('Error processing message:', error);
        await message.reply('❌ Internal error occurred, please try again later!');
    }
});

// Handle errors
client.on('error', (error) => {
    console.error('Discord Client Error:', error);
});

process.on('unhandledRejection', (error) => {
    console.error('Unhandled Promise Rejection:', error);
});

client.login(config.discord.token);
