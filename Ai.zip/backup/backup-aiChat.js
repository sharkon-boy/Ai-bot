const axios = require('axios');

class AIChatSystem {
    constructor(apiKey) {
        this.apiKey = apiKey;
        this.availableModels = [
            "llama-3.1-8b-instant",
            "llama-3.1-70b-versatile", 
            "mixtral-8x7b-32768",
            "gemma2-9b-it"
        ];
    }

    async chatWithAI(prompt) {
        try {
            const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
                model: "llama-3.1-8b-instant",
                messages: [{ role: "user", content: prompt }],
                temperature: 0.7,
                max_tokens: 1024,
                stream: false
            }, {
                headers: {
                    'Authorization': `Bearer ${this.apiKey}`,
                    'Content-Type': 'application/json'
                },
                timeout: 30000
            });
            
            return response.data.choices[0].message.content;
        } catch (error) {
            if (error.response?.data?.error?.message) {
                console.error('AI API Error:', error.response.data.error.message);
            } else {
                console.error('AI API Error:', error.message);
            }
            
            if (error.response?.data?.error?.code === 'model_decommissioned') {
                return await this.tryAlternativeModel(prompt);
            }
            
            const fallbackResponses = [
                "Sorry, I'm busy right now. Try again later!",
                "AI server is currently full, please wait a moment!",
                "Oops, an error occurred. Try asking again!",
                "I can't respond at the moment, please try again later!"
            ];
            
            return fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)];
        }
    }

    async tryAlternativeModel(prompt) {
        const alternativeModels = this.availableModels.slice(1);
        
        for (const model of alternativeModels) {
            try {
                const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
                    model: model,
                    messages: [{ role: "user", content: prompt }],
                    temperature: 0.7,
                    max_tokens: 512
                }, {
                    headers: {
                        'Authorization': `Bearer ${this.apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 15000
                });
                
                return response.data.choices[0].message.content;
            } catch (error) {
                continue;
            }
        }
        
        return "Sorry, all models are currently unavailable. Please try again later!";
    }
}

module.exports = AIChatSystem;
