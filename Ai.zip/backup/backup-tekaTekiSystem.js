const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const fs = require('fs').promises;
const path = require('path');
const cron = require('node-cron');
const cmdIcons = require('../UI/icons/commandicons');

class TekaTekiSystem {
    constructor() {
        this.dataPath = path.join(__dirname, '..', 'data', 'TEKATEKIDATA.json');
        this.currentTekaTeki = null;
        this.lastUpdate = null;
        this.usedIds = new Set();
        this.userScores = new Map();
        this.dailyChannelId = null;
        this.activeMessages = new Map();

        // GIF untuk jawaban BENAR
        this.correctGifs = [
            'https://media.giphy.com/media/3o7abKhOpu0NwenH3O/giphy.gif',
            'https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif',
            'https://media.giphy.com/media/xULW8N9L6aA0aZqJk4/giphy.gif',
            'https://media.giphy.com/media/3o72FfM5HJydzafgUE/giphy.gif',
            'https://media.giphy.com/media/26tOZ42Mg6pbTUPHW/giphy.gif'
        ];
        
        // GIF untuk jawaban SALAH
        this.wrongGifs = [
            'https://media.giphy.com/media/l3q2K5jinAlChoCLS/giphy.gif',
            'https://media.giphy.com/media/3o7aD2sNQwM2NvTtjW/giphy.gif',
            'https://media.giphy.com/media/3o7TKSha51ATTx9KzC/giphy.gif',
            'https://media.giphy.com/media/3o7WTGhpD4k3zRZzD2/giphy.gif',
            'https://media.giphy.com/media/3o7aD5zYLSc0meVKCQ/giphy.gif'
        ];
    }

    // === TAMBAHKAN FUNGSI RESET ===
    resetTekaTeki() {
        this.usedIds.clear();
        this.currentTekaTeki = null;
        this.lastUpdate = null;
        return true;
    }

    // Fungsi untuk mendapatkan GIF random
    getRandomCorrectGif() {
        const randomIndex = Math.floor(Math.random() * this.correctGifs.length);
        return this.correctGifs[randomIndex];
    }

    getRandomWrongGif() {
        const randomIndex = Math.floor(Math.random() * this.wrongGifs.length);
        return this.wrongGifs[randomIndex];
    }

    async loadTekaTekiData() {
        try {
            const data = await fs.readFile(this.dataPath, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            return { tekaTeki: [] };
        }
    }

    async getRandomTekaTeki() {
        try {
            const data = await this.loadTekaTekiData();
            const totalTekaTeki = data.tekaTeki.length;
            
            if (totalTekaTeki === 0) return null;

            // Jika semua sudah digunakan, reset
            if (this.usedIds.size >= totalTekaTeki) {
                this.usedIds.clear();
            }

            const availableTekiTeki = data.tekaTeki.filter(t => !this.usedIds.has(t.id));
            
            if (availableTekiTeki.length === 0) {
                this.usedIds.clear();
                return this.getRandomTekaTeki();
            }

            const randomIndex = Math.floor(Math.random() * availableTekiTeki.length);
            const selectedTekiTeki = availableTekiTeki[randomIndex];
            
            this.usedIds.add(selectedTekiTeki.id);
            this.currentTekaTeki = selectedTekiTeki;
            this.lastUpdate = new Date();
            
            return selectedTekiTeki;
        } catch (error) {
            return null;
        }
    }

    getCurrentTekaTeki() {
        return this.currentTekaTeki;
    }

    checkAnswer(selectedOption) {
        if (!this.currentTekaTeki) return false;
        return selectedOption === this.currentTekaTeki.jawaban;
    }

    shouldRefreshDaily() {
        if (!this.lastUpdate) return true;
        const now = new Date();
        const lastUpdate = new Date(this.lastUpdate);
        return now.toDateString() !== lastUpdate.toDateString();
    }

    updateUserScore(userId) {
        const currentScore = this.userScores.get(userId) || 0;
        this.userScores.set(userId, currentScore + 1);
        return currentScore + 1;
    }

    getUserScore(userId) {
        return this.userScores.get(userId) || 0;
    }

    getLeaderboard() {
        return Array.from(this.userScores.entries())
            .map(([userId, score]) => ({ userId, score }))
            .sort((a, b) => b.score - a.score);
    }

    setDailyChannel(channelId) {
        this.dailyChannelId = channelId;
        return channelId;
    }

    getDailyChannel() {
        return this.dailyChannelId;
    }

    // Membuat embed dengan tombol pilihan
    createTekaTekiEmbed(tekaTeki) {
        if (!tekaTeki) {
            return {
                embed: new EmbedBuilder()
                    .setAuthor({
                        name: 'Error System',
                        iconURL: cmdIcons.dotIcon
                    })
                    .setTitle('❌ ERROR')
                    .setDescription('Teka-teki tidak ditemukan')
                    .setColor(0xFF0000),
                components: []
            };
        }

        const embed = new EmbedBuilder()
            .setAuthor({
                name: 'Teka-Teki',
                iconURL: cmdIcons.alarmIcon
            })
        //    .setTitle('🎯 TEKA-TEKI HARIAN')
            .setDescription(`**${tekaTeki.pertanyaan}**`)
            .setColor(0x00AE86)
            .addFields(
                { name: '📁 Kategori', value: tekaTeki.kategori, inline: true },
                { name: '💡 Petunjuk', value: tekaTeki.petunjuk || 'Tidak ada petunjuk', inline: true }
            )
            .setFooter({ text: 'Pilih jawaban dengan mengklik tombol di bawah!' })
            .setTimestamp();

        // Membuat tombol pilihan
        const row = new ActionRowBuilder();
        
        Object.entries(tekaTeki.pilihan).forEach(([key, value]) => {
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId(`teki_${key}`)
                    .setLabel(`${key.toUpperCase()}. ${value}`)
                    .setStyle(ButtonStyle.Primary)
            );
        });

        return {
            embed: embed,
            components: [row]
        };
    }

    createCorrectEmbed(user, selectedAnswer, correctAnswer) {
        const randomGif = this.getRandomCorrectGif();
        
        return new EmbedBuilder()
            .setAuthor({
                name: 'Jawaban Benar 🎉',
                iconURL: cmdIcons.catIcon
            })
            .setTitle('🎉 SELAMAT!')
            .setDescription(`**${user.username}** menjawab dengan benar! 🎊`)
            .setColor(0x00FF00)
            .addFields(
                { name: '✅ Jawaban Benar', value: `${correctAnswer.toUpperCase()}. ${this.currentTekaTeki.pilihan[correctAnswer]}`, inline: true },
                { name: '🏆 Skor Sekarang', value: `${this.getUserScore(user.id)} poin`, inline: true }
            )
            .setImage(randomGif)
            .setTimestamp();
    }

    createWrongEmbed(user, selectedAnswer, correctAnswer) {
        const randomGif = this.getRandomWrongGif();
        
        return new EmbedBuilder()
            .setAuthor({
                name: 'Jawaban Salah ❌',
                iconURL: cmdIcons.plerIcon
            })
       //     .setTitle('❌ SALAH!')
            .setDescription(`**${user.username}**, jawabanmu masih salah. Jangan menyerah! 💪`)
            .setColor(0xFF0000)
            .addFields(
                { name: '❌ Jawaban Kamu', value: `${selectedAnswer.toUpperCase()}. ${this.currentTekaTeki.pilihan[selectedAnswer]}`, inline: true },
                { name: '✅ Jawaban Benar', value: `${correctAnswer.toUpperCase()}. ${this.currentTekaTeki.pilihan[correctAnswer]}`, inline: true }
            )
            .setImage(randomGif)
            .setTimestamp();
    }

    createLeaderboardEmbed(leaderboard, client) {
        const embed = new EmbedBuilder()
            .setAuthor({
                name: 'Leaderboard System',
                iconURL: cmdIcons.ZIcon
            })
         //   .setTitle('🏆 LEADERBOARD TEKA-TEKI')
            .setColor(0xFFD700);

        if (leaderboard.length === 0) {
            embed.setDescription('Belum ada yang bermain!');
        } else {
            let description = '';
            leaderboard.slice(0, 10).forEach((entry, index) => {
                const user = client.users.cache.get(entry.userId);
                const username = user ? user.username : 'Unknown User';
                const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '🔸';
                description += `${medal} **${username}** - ${entry.score} poin\n`;
            });
            embed.setDescription(description);
        }

        return embed;
    }

    // Menangani interaksi tombol
    async handleButtonInteraction(interaction) {
        if (!interaction.isButton()) return;
        
        const customId = interaction.customId;
        if (!customId.startsWith('teki_')) return;

        const selectedOption = customId.replace('teki_', '');
        const isCorrect = this.checkAnswer(selectedOption);
        
        // Update skor jika benar
        if (isCorrect) {
            this.updateUserScore(interaction.user.id);
        }

        // Nonaktifkan tombol setelah dijawab
        const disabledRow = new ActionRowBuilder();
        Object.entries(this.currentTekaTeki.pilihan).forEach(([key, value]) => {
            const isThisCorrect = key === this.currentTekaTeki.jawaban;
            disabledRow.addComponents(
                new ButtonBuilder()
                    .setCustomId(`teki_${key}`)
                    .setLabel(`${key.toUpperCase()}. ${value}`)
                    .setStyle(isThisCorrect ? ButtonStyle.Success : (key === selectedOption ? ButtonStyle.Danger : ButtonStyle.Secondary))
                    .setDisabled(true)
            );
        });

        await interaction.update({ components: [disabledRow] });

        // Kirim embed hasil dengan GIF
        if (isCorrect) {
            const embed = this.createCorrectEmbed(interaction.user, selectedOption, this.currentTekaTeki.jawaban);
            await interaction.followUp({ 
                embeds: [embed], 
                ephemeral: false 
            });
        } else {
            const embed = this.createWrongEmbed(interaction.user, selectedOption, this.currentTekaTeki.jawaban);
            await interaction.followUp({ 
                embeds: [embed], 
                ephemeral: false 
            });
        }
    }

    // Schedule daily reset
    startDailyScheduler(client) {
        try {
            // Reset setiap hari jam 08:00 WIB
            cron.schedule('0 8 * * *', async () => {
                // Reset usedIds setiap hari baru
                this.usedIds.clear();
                await this.getRandomTekaTeki();
                
                // Kirim ke channel yang ditentukan
                if (this.dailyChannelId) {
                    try {
                        const channel = await client.channels.fetch(this.dailyChannelId);
                        if (channel) {
                            const newTekaTeki = this.getCurrentTekaTeki();
                            const { embed, components } = this.createTekaTekiEmbed(newTekaTeki);
                            await channel.send({ 
                                content: '🎯 **TEKA-TEKI BARU HARI INI!** 🎯\nKlik tombol untuk menjawab!',
                                embeds: [embed],
                                components: components
                            });
                        }
                    } catch (error) {
                        // Silent error
                    }
                }
            });
        } catch (error) {
            // Silent error
        }
    }

    // Manual send teka-teki dengan reset
    async sendTekaTeki(channel) {
        // Reset dulu agar dapat teka-teki baru
        this.resetTekaTeki();
        await this.getRandomTekaTeki();
        
        const currentTeki = this.getCurrentTekaTeki();
        if (currentTeki) {
            const { embed, components } = this.createTekaTekiEmbed(currentTeki);
            return await channel.send({ 
                content: '🎯 **TEKA-TEKI HARIAN**\nKlik tombol untuk menjawab!',
                embeds: [embed],
                components: components
            });
        }
        return null;
    }
}

module.exports = TekaTekiSystem;
