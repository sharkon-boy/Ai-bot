const { Client, GatewayIntentBits, ActivityType, Events } = require('discord.js');

// Import modules
const TekaTekiSystem = require('./modules/tekaTekiSystem');
const AIChatSystem = require('./modules/aiChat');

// Config
const config = {
    discord: {
        token: "MTM3NzQ3OTUyMDAyNTcxMDY0NQ.GONlu2.fRbRlS8kgOeaYLUPhpo8gw8xHFwIHQdjzXLVMw",
        clientId: "1377479520025710645"
    },
    groq: {
        apiKey: "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"
    },
    channels: {
        allowed_channel_ids: ["1238693417975025704"]
    }
};

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

// Initialize systems
const tekaTekiSystem = new TekaTekiSystem();
const aiChatSystem = new AIChatSystem(config.groq.apiKey);

client.on('ready', async () => {
    console.log(`✅ Bot successfully logged in as ${client.user.tag}`);
    console.log(`🤖 AI System: Groq API`);
    console.log(`🎯 Teka-Teki System: Active`);
    
    // Load initial teka-teki
    const loadedTeki = await tekaTekiSystem.getRandomTekaTeki();
    if (loadedTeki) {
        console.log('📝 Teka-teki harian loaded successfully');
    } else {
        console.log('❌ Failed to load teka-teki');
    }
    
    // Start daily scheduler
    tekaTekiSystem.startDailyScheduler(client);
    
    client.user.setPresence({
        activities: [{ 
            name: 'AI & Teka-Teki | !help', 
            type: ActivityType.Playing 
        }],
        status: 'online'
    });
});

// Handle button interactions
client.on(Events.InteractionCreate, async (interaction) => {
    if (interaction.isButton()) {
        await tekaTekiSystem.handleButtonInteraction(interaction);
        return;
    }
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    
    // Check if channel is allowed
    if (!config.channels.allowed_channel_ids.includes(message.channel.id)) {
        return;
    }

    const content = message.content.toLowerCase().trim();

    // ==================== TEKA-TEKI COMMANDS ====================
    if (content.startsWith('!teki')) {
        await handleTekaTekiCommands(message, content);
        return;
    }

    // ==================== AI CHAT COMMANDS ====================
    if (content.startsWith('!help')) {
        await sendHelpMessage(message);
        return;
    }

    if (content.startsWith('!info')) {
        return message.reply('🤖 This bot uses Groq API with Llama 3.1 + Teka-Teki System Interaktif!');
    }

    if (content.startsWith('!model')) {
        return message.reply('🚀 **Current Model:** Llama 3.1 8B Instant\n🎯 **Teka-Teki:** Active dengan Tombol\n⚡ **Speed:** Very Fast');
    }

    // Ignore short messages or other commands
    if (message.content.length < 2 || message.content.startsWith('!')) return;

    // Process as AI chat
    try {
        message.channel.sendTyping();
        const aiResponse = await aiChatSystem.chatWithAI(message.content);
        
        if (aiResponse && aiResponse.length > 2000) {
            const chunks = aiResponse.match(/[\s\S]{1,1990}/g);
            for (let i = 0; i < Math.min(chunks.length, 3); i++) {
                if (i === 0) {
                    await message.reply(chunks[i] + `\n\n[Part ${i+1}/${chunks.length}]`);
                } else {
                    await message.channel.send(chunks[i] + `\n\n[Part ${i+1}/${chunks.length}]`);
                }
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        } else if (aiResponse) {
            await message.reply(aiResponse);
        }
    } catch (error) {
        console.error('Error processing AI message:', error);
        await message.reply('❌ Internal error occurred, please try again later!');
    }
});

// Teka-teki command handler
async function handleTekaTekiCommands(message, content) {
    const args = content.split(' ');
    const subCommand = args[1];

    console.log(`🎯 Teka-teki command: ${content}`);

    switch (subCommand) {
        case 'skor':
            const score = tekaTekiSystem.getUserScore(message.author.id);
            await message.reply(`🏆 **Skor Anda:** ${score} poin`);
            break;

        case 'top':
        case 'leaderboard':
            const leaderboard = tekaTekiSystem.getLeaderboard();
            const embed = tekaTekiSystem.createLeaderboardEmbed(leaderboard, client);
            await message.reply({ embeds: [embed] });
            break;

        case 'channel':
            if (!message.member.permissions.has('MANAGE_CHANNELS')) {
                return message.reply('❌ Anda perlu permission "Manage Channels" untuk menggunakan command ini.');
            }
            tekaTekiSystem.setDailyChannel(message.channel.id);
            await message.reply('✅ Channel ini sekarang akan menerima teka-teki harian otomatis setiap jam 08:00 WIB!');
            break;

        case 'manual':
            if (!message.member.permissions.has('MANAGE_MESSAGES')) {
                return message.reply('❌ Anda perlu permission "Manage Messages" untuk menggunakan command ini.');
            }
            await tekaTekiSystem.sendTekaTeki(message.channel);
            break;

        default:
            // Show current teka-teki
            await tekaTekiSystem.sendTekaTeki(message.channel);
    }
}

// Help message
async function sendHelpMessage(message) {
    const helpMessage = `
🤖 **BOT COMMANDS:**

**AI Chat:**
• **!help** - Show this help
• **!info** - Bot information  
• **!model** - Check current model
• **Type any message** - Chat with AI

**🎯 Teka-Teki System (INTERAKTIF):**
• **!teki** - Dapatkan teka-teki harian dengan tombol
• **!teki skor** - Lihat skor pribadi
• **!teki top** - Leaderboard
• **!teki channel** - Set channel harian (admin)
• **!teki manual** - Manual kirim teka-teki (admin)

📊 **AI:** Groq API + Llama 3.1
🎮 **Teka-Teki:** Sistem interaktif dengan tombol pilihan
⏰ **Auto-send:** Setiap hari 08:00 WIB
⚡ **Status:** Active & Interactive
    `;
    await message.reply(helpMessage);
}

// Error handling
client.on('error', (error) => {
    console.error('Discord Client Error:', error);
});

process.on('unhandledRejection', (error) => {
    console.error('Unhandled Promise Rejection:', error);
});

client.login(config.discord.token);
